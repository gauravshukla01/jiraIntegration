package com.qa.data;

public class Execution_TS {
/*int issueId;
int projectId;*/
String status;
public Execution_TS(){
	
}
//public Execution_TS(int issueId,int projectId,int status){
public Execution_TS(String status){

/*	this.issueId=issueId;
	this.projectId=projectId;*/
	this.status=status;			
}
//getter ans setter
/*public int getIssueId() {
	return issueId;
}
public void setIssueId(int issueId) {
	this.issueId = issueId;
}
public int getProjectId() {
	return projectId;
}
public void setProjectId(int projectId) {
	this.projectId = projectId;
}*/
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
	
}
