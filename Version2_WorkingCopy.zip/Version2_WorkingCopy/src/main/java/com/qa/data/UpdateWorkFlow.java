package com.qa.data;

public class UpdateWorkFlow {
String id;

public UpdateWorkFlow(String id){
//public Execution(int status){

	this.id=id;
}
//getter ans setter
public String getid() {
	return id;
}
public void setid(String id) {
	this.id = id;
}
}
