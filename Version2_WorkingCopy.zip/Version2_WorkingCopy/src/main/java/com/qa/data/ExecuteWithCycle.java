package com.qa.data;

public class ExecuteWithCycle {
String issueId;
int projectId;
int status;
String cycleId;
//int versionId;
public ExecuteWithCycle(){
	
}
public ExecuteWithCycle(String issueId,int projectId,int status,String cycleId){//,int versionId){
//public Execution(int status){

	this.issueId=issueId;
	this.projectId=projectId;
	this.status=status;
	this.cycleId=cycleId;
	//this.versionId=versionId;
	
}
//getter ans setter
public String getIssueId() {
	return issueId;
}
public void setIssueId(String issueId) {
	this.issueId = issueId;
}
public int getProjectId() {
	return projectId;
}
public void setProjectId(int projectId) {
	this.projectId = projectId;
}
public int getStatus() {
	return status;
}
public void setStatus(int status) {
	this.status = status;
}
public String getcycleId() {
	return cycleId;
}
public void setcycleId(String cycleId) {
	this.cycleId = cycleId;
}	
/*
public int getversionId() {
	return versionId;
}
public void setversionId(int versionId) {
	this.versionId = versionId;
}*/
}
