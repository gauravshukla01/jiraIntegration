package com.qa.data;

public class TestStep {
String step;
String data;
String result;
public TestStep(String step,String data,String result){
	this.step=step;
	this.data=data;
	this.result=result;	
}
public String getStep() {
	return step;
}
public void setStep(String step) {
	this.step = step;
}
public String getData() {
	return data;
}
public void setData(String data) {
	this.data = data;
}
public String getResult() {
	
	return result;
}
public void setResult(String result) {
	this.result = result;
}
}
