package com.qa.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.json.JSONObject;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.qa.test.NewTSExecution;
//import com.qa.test.NewTSExecution_R$D;

public class TestCaseWithOutSprint {
public static String summary;
public static String description;
public static String customfield_10100;
//public static String customfield_10004;
//static HashMap<String, String> issuetype;
	public static Map<String, Object> issuetype = new HashMap<String, Object>();
	public static Map<String, Object> project = new HashMap<String, Object>();
	public static Map<String, Object> assignee = new HashMap<String, Object>();
	public static Map<String, Object> priority = new HashMap<String, Object>();
	public static Map<String, Object> customfield_13500 =new HashMap<String, Object>();
	public static ArrayList label =new ArrayList();
	//public static int customfield_10004;
	//customfield_10004
	
//Map project,assignee,priority,customfield_13500;
//ArrayList labels[];
//"issue type","Project","Summary","description","assigne","priority","",""

public TestCaseWithOutSprint(Map<String, Object> issuetype,Map<String, Object> project,Map<String, Object> assignee,Map<String, Object> priority,String summary,String description,Map<String, Object> customfield_13500,String customfield_10100,ArrayList<String> label){
	this.issuetype=issuetype;
	this.summary=summary;
	this.description=description;
	this.customfield_10100=customfield_10100;
	//this.customfield_10004=customfield_10004;
	this.project=project;
	this.assignee=assignee;
	this.priority=priority;
	this.customfield_13500=customfield_13500;
	this.label=label;
	//this.customfield_10004=customfield_10004;
	
}
public String getSummary() {
	return summary;
}
public void setSummary(String summary) {
	this.summary = summary;
}
public String getDescription() {
	
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public String getCustomfield_10100() {
	return customfield_10100;
}
public void setCustomfield_10100(String customfield_10100) {
	this.customfield_10100 = customfield_10100;
}
/*public String getCustomfield_10004() {
	return customfield_10004;
}
public void setCustomfield_10004(String customfield_10004) {
	this.customfield_10004 = customfield_10004;
}*/
public  Map<String, Object> getProject() {
	Map<String, Object> project = new HashMap<String, Object>();
	project.put("key",NewTSExecution.projectName);
	//System.out.println(project);
	//return priority;
	return project;
}

public static void setProject(Map<String, Object> project) {
	TestCaseWithOutSprint.project = project;
}

public  Map<String, Object> getAssignee() {
	
	Map<String, Object> assignee = new HashMap<String, Object>();
	assignee.put("name",NewTSExecution.Assignee);
	//System.out.println(assignee);
	//return priority;
	return assignee;
}

public static void setAssignee(Map<String, Object> assignee) {
	TestCaseWithOutSprint.assignee = assignee;
}

public  Map<String, Object> getPriority() {
	Map<String, Object> priority = new HashMap<String, Object>();
	priority.put("name",NewTSExecution.Priority);
	
	//System.out.println(priority);
	//return priority;
	return priority;
}

public static void setPriority(Map<String, Object> priority) {
	TestCaseWithOutSprint.priority = priority;
}

public Map<String, Object> getIssuetype() {
	Map<String, Object> issuetype = new HashMap<String, Object>();
	//issuetype.put("name","JavaInterviewPoint");
    //issuetype.put("department","IT");
	 
	issuetype.put("name",NewTSExecution.customfield_13500_IT);
	
	//System.out.println(issuetype);
	return issuetype;
}
public void setIssuetype() {
	issuetype = new HashMap<String,Object>();
	issuetype.put("name","Test");
	//System.out.println(issuetype);
//	this.issuetype = issuetype;
	
}
public Map getCustomfield_13500() {
	Map<String, Object> testtype = new HashMap<String, Object>();
	testtype.put("value",NewTSExecution.customfield_13500_TT);
	return testtype;
}
public void setCustomfield_13500(Map customfield_13500) {
	this.customfield_13500 = customfield_13500;
}

public ArrayList getLabels() {
	label=new ArrayList();
	label.add(NewTSExecution.labels);
	return label;
}
public void setLabels(ArrayList label) {
	this.label = label;
}

/*public int getcustomfield_10004() {
	//customfield_10004=new ArrayList();
	customfield_10004=NewTSExecution.sprintID;
	return customfield_10004;
}
public void setcustomfield_10004() {
	this.customfield_10004 = customfield_10004;
}*/
/*public Map getProject() {
	return project;
}
public void setProject(Map project) {
	this.project = project;
}
public Map getAssignee() {
	return assignee;
}
public void setAssignee(Map assignee) {
	
	this.assignee = assignee;
}
public Map getPriority() {
	return priority;
}
public void setPriority(Map priority) {
	this.priority = priority;
}
public Map getCustomfield_13500() {
	return customfield_13500;
}
public void setCustomfield_13500(Map customfield_13500) {
	this.customfield_13500 = customfield_13500;
}
public ArrayList[] getLabels() {

	return labels;
}
public void setLabels(ArrayList[] labels) {
	this.labels = labels;
}*/
/*public static void main(String args[]){
	TestCase testcase=new TestCase(getIssuetype(),null,"issue type","Project",null,null,null,"description",null);
	setIssuetype(issuetype);
}*/
}
