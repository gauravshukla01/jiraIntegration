package com.qa.client;

import java.io.Closeable;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.StringUtils;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.AuthenticationException;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContextBuilder;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.qa.test.ExecuteExisiting;
import com.qa.test.GetAPITest;
import com.qa.base.TestBase;
import io.restassured.http.Header;
import com.qa.test.ExecuteExisiting;
public class RestClient extends TestBase{
	//public Properties prop;
	 
	public static String id;
	public static CloseableHttpClient httpClient;
	public static HttpGet httpget;
	public static CloseableHttpResponse closehttpresponse;
	//prop =new Properties();
	//String TestCycleName=prop.getProperty("TestCycleName");
	String TestCycleName=prop.getProperty("TestCycleName");
	public static String user=prop.getProperty("UserName");
	public static String pwd=decryptPwd(prop.getProperty("EncryptedPassword"));
	String endpointurl=prop.getProperty("Host");
	ExecuteExisiting postAPITest2=new ExecuteExisiting();
	public static String url5;
	
public String get(String url) throws ClientProtocolException,IOException, JSONException, AuthenticationException{
	
	 httpClient=HttpClients.createDefault();
	 httpget=new HttpGet(url);	

    UsernamePasswordCredentials creds
      = new UsernamePasswordCredentials(user, pwd);
    httpget.addHeader(new BasicScheme().authenticate(creds, httpget, null));
		
	 closehttpresponse=httpClient.execute(httpget);
	int StatusCode=closehttpresponse.getStatusLine().getStatusCode();
	
	System.out.println("Staus Code====="+StatusCode);
	
	String response=EntityUtils.toString(closehttpresponse.getEntity());
	
	 System.out.println("Execution id----"+ response.substring(3,7));
	
	JSONObject responsejson=new JSONObject(response.substring(response.indexOf('{')));
	//responsejson.get
	System.out.println("Response JSON"+response);
	/*org.apache.http.Header[] headerarray= closehttpresponse.getAllHeaders();
	HashMap<String,String> allheaders=new HashMap<String,String>();
	for(org.apache.http.Header header:headerarray){
		allheaders.put(header.getName(),header.getValue());
	}*/
	//System.out.println("Headers are ===="+allheaders);
	if(response.charAt(0)=='['){
	JSONArray jsonarray=new JSONArray(response); 
	for(int i=0; i<jsonarray.length(); i++){
        JSONObject obj = jsonarray.getJSONObject(i);
        System.out.println("****" +obj.getString("id"));
    
        System.out.println("Test Step["+i+"] ID is "+obj.get("id"));
        url5=endpointurl+"/rest/zapi/latest/stepResult/"+obj.get("id")+"";
        postAPITest2.putAPITSTest();

    }   
	}
	try{
	id = (String) responsejson.get("id");
	 System.out.println("id is=------"+id);
	}catch(Exception e){
		id =String.valueOf(responsejson.get("id"));  
		 System.out.println("id is=------"+id);
	}
	 return id;
	//closehttpresponse.
}
public CloseableHttpResponse post(String url,String entitystring,HashMap<String,String> headermap) throws ClientProtocolException,IOException, JSONException, AuthenticationException{
	
	CloseableHttpClient httpClient=HttpClients.createDefault();
	//httpClient=HttpClients.custom().setDefaultCredentialsProvider(credsProvider).build();
	//httpClient=createHttpClient("pkoth15","May@2018");
	httpClient=HttpClients.createDefault();
	HttpPost httppost=new HttpPost(url);
	
	httppost.setEntity(new StringEntity("test post"));
    UsernamePasswordCredentials creds
      = new UsernamePasswordCredentials(user, pwd);
    httppost.addHeader(new BasicScheme().authenticate(creds, httppost, null));
    
	//httppost.setEntity(new UrlEncodedFormEntity(params));
	httppost.setEntity(new StringEntity(entitystring));
	for(Map.Entry<String, String> entry: headermap.entrySet()){
		httppost.addHeader(entry.getKey(),entry.getValue());
	}
	CloseableHttpResponse closablehttpresponse= httpClient.execute(httppost);
	return closablehttpresponse;
	}
public CloseableHttpResponse put(String url,String entitystring,HashMap<String,String> headermap) throws ClientProtocolException,IOException, JSONException, AuthenticationException{
	
	CloseableHttpClient httpClient=HttpClients.createDefault();
	//httpClient=HttpClients.custom().setDefaultCredentialsProvider(credsProvider).build();
	//httpClient=createHttpClient("pkoth15","May@2018");
	httpClient=HttpClients.createDefault();
	HttpPut httpput=new HttpPut(url);
	
	httpput.setEntity(new StringEntity("test post"));
    UsernamePasswordCredentials creds
      = new UsernamePasswordCredentials(user, pwd);
    httpput.addHeader(new BasicScheme().authenticate(creds, httpput, null));
    
	//httppost.setEntity(new UrlEncodedFormEntity(params));
    httpput.setEntity(new StringEntity(entitystring));
	for(Map.Entry<String, String> entry: headermap.entrySet()){
		httpput.addHeader(entry.getKey(),entry.getValue());
	}
	CloseableHttpResponse closablehttpresponse= httpClient.execute(httpput);
	return closablehttpresponse;
	}
public static String decryptPwd(String Name)
{
	byte[] decodeBytes = Base64.decodeBase64(Name);
	String decodedString = new String(decodeBytes);
	return decodedString;
}
public String getID(String url) throws ClientProtocolException,IOException, JSONException, AuthenticationException{
	
	CloseableHttpClient httpClient=HttpClients.createDefault();

	HttpGet httpget=new HttpGet(url);
	

    UsernamePasswordCredentials creds
      = new UsernamePasswordCredentials(user, pwd);
    httpget.addHeader(new BasicScheme().authenticate(creds, httpget, null));
	
	
	CloseableHttpResponse closehttpresponse=httpClient.execute(httpget);
	
	
	
	
	int StatusCode=closehttpresponse.getStatusLine().getStatusCode();
	
	System.out.println("Staus Code====="+StatusCode);
	
	String response=EntityUtils.toString(closehttpresponse.getEntity());
	
	 System.out.println("Execution id----"+ response.substring(3,7));
	
	JSONObject responsejson=new JSONObject(response.substring(response.indexOf('{')));
	//responsejson.get
	System.out.println("Response JSON"+response);
	org.apache.http.Header[] headerarray= closehttpresponse.getAllHeaders();
	HashMap<String,String> allheaders=new HashMap<String,String>();
	for(org.apache.http.Header header:headerarray){
		allheaders.put(header.getName(),header.getValue());
	}
	
	
	JSONArray jsonarray=new JSONArray(response); 
	for(int i=0; i<jsonarray.length(); i++){
        JSONObject obj = jsonarray.getJSONObject(i);

        String id = obj.getString("name");
     

        System.out.println(id);
        //System.out.println(url);
    }   
 
	//System.out.println("firsdt ele"+arg.get(0).toString());
	//System.out.println("Headers are ===="+allheaders);
	try{
	id = (String) responsejson.get("id");
	//String reqid = StringUtils.(id);
	 System.out.println("id is=------"+id);
	}catch(Exception e){
		id =String.valueOf(responsejson.get("id"));  
		 System.out.println("id is=------"+id);
	}
	 return id;
	//closehttpresponse.
}
}



