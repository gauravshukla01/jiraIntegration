package com.qa.test;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
//import org.apache.poi.openxml4j.opc.Package;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcelFile {

	static XSSFSheet ExcelWSheet;
	static XSSFWorkbook ExcelWBook;
	static XSSFCell Cell;
	static FileInputStream fis = null;
	static XSSFRow row;

	public static String getCellData(int RowNum, int ColNum) throws Exception {
		Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);
		String CellData = Cell.getStringCellValue().toString();
		return CellData;
	}

	public static void main(String[] args) throws Exception {

		fis = new FileInputStream(("./ExcelSheet/JIRAUpload123.xlsx"));

		ExcelWBook = new XSSFWorkbook(fis);
		ExcelWSheet = ExcelWBook.getSheetAt(0);

		int desrow = 0;
		int intDesclm = 0;
		int s=0;
        int chk=0;
        int test=1;
		for (int ir = 0; ir <= ExcelWSheet.getLastRowNum(); ir++) {

			//System.out.println(":::Row::" + ir + "::Max cal::" + ExcelWSheet.getPhysicalNumberOfRows());
			for (int jC = 0; jC <= ExcelWSheet.getPhysicalNumberOfRows(); jC++) {

				String dis = ReadExcelFile.getCellData(ir, jC);

				if (dis.contains("Description")) {
					System.out.println(":::dis is matching discripy::");
					desrow = ir;
					intDesclm = jC;
					System.out.println("Matchi9ng::Row::" + desrow + "::Maching column::" +intDesclm);
					String dis1 = ReadExcelFile.getCellData(desrow+1, intDesclm);

					System.out.println(":::::::::::::New Test case:::::::::::"+test+++"::::::::::::");
					System.out.println(desrow+":::Discription::"+dis1);
				chk=1;
				break;
          			}
				
			}
			if(chk>=1)
			{
				break;
			}
			
		}
		
		for(int i=1;i<ExcelWSheet.getLastRowNum();i++)
		{
			String dis1 = ReadExcelFile.getCellData(i, intDesclm);
			String Step = ReadExcelFile.getCellData(i, intDesclm+1);
			String Exptval = ReadExcelFile.getCellData(i, intDesclm+8);
			String Testdata= ReadExcelFile.getCellData(i, intDesclm+7);
			/*String Priority
			Assignee 
			Labels 
			*/
			
			
			System.out.println(":::Step:::::::::"+Step);
			System.out.println(":::Expected:::::"+Exptval);
			System.out.println(":::Test Data:::::"+Testdata);
			
			//read step n expected  
			s=i+1;
			String nextdis1 = ReadExcelFile.getCellData(s, intDesclm);
			
			if(!nextdis1.isEmpty())
			{
				
				System.out.println(":::::::::::::New Test case:::::::::::"+test+++"::::::::::::");
				System.out.println("::We are goint to next test case::::::::::");
				System.out.println(":::Discription::"+nextdis1);
				
			}
		}
	}
}

/*static /*public static void readXLSFile() {
try {
	InputStream ExcelFileToRead = new FileInputStream(EXCEL_FILE);
	HSSFWorkbook wb = new HSSFWorkbook(ExcelFileToRead);

	HSSFSheet sheet = wb.getSheetAt(0);
	HSSFRow row;
	HSSFCell cell;

	Iterator rows = sheet.rowIterator();

	while (rows.hasNext()) {
		row = (HSSFRow) rows.next();
		Iterator cells = row.cellIterator();

		while (cells.hasNext()) {
			cell = (HSSFCell) cells.next();
			System.out.print(cell.toString()+" ");
		}
		System.out.println();
	}

} catch (Exception e) {
	e.printStackTrace();
}

}

public static void readXLSFileWithBlankCells() {
try {
	InputStream ExcelFileToRead = new FileInputStream(EXCEL_FILE);
	HSSFWorkbook wb = new HSSFWorkbook(ExcelFileToRead);

	HSSFSheet sheet = wb.getSheetAt(0);
	HSSFRow row;
	HSSFCell cell;

	Iterator rows = sheet.rowIterator();

	while (rows.hasNext()) {
		row = (HSSFRow) rows.next();
		
		for(int i=0; i<row.getLastCellNum(); i++) {
			cell = row.get
					getCell(i, Row.CREATE_NULL_AS_BLANK);
			if(!(cell==null)){
			System.out.println(cell.toString()+" ");
			}
			else{
				
			}
		}
		System.out.println();
	}

} catch (Exception e) {
	e.printStackTrace();
}

}

XSSFSheet ExcelWSheet;
XSSFWorkbook ExcelWBook;
static XSSFCell Cell;


public static String getCellData(int RowNum, int ColNum) throws Exception{
 Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);
 String CellData = Cell.getStringCellValue();
 return CellData;
}



public static void main(String[] args) throws IOException {
//readXLSFile();
//	readXLSFileWithBlankCells();
FileInputStream fis = new FileInputStream(("./ExcelSheet/JIRAUpload123.xlsx"));
//InputStream ExcelFileToRead = new FileInputStream(EXCEL_FILE);
//HSSFWorkbook wb = new HSSFWorkbook(fis);
/* XSSFWorkbook workbook = new XSSFWorkbook(fis);
XSSFSheet sheet = workbook.getSheetAt(0);
XSSFRow row = sheet.getRow(0);
*/






            //This method is to set the File path and to open the Excel file
          

            //This method is to read the test data from the Excel cell
            //In this we are passing parameters/arguments as Row Num and Col Num
            















/*
for(int i=0; i <= row.getLastCellNum(); i++)
{
    if(row.getCell(i).getStringCellValue().trim().equals("Description")){
    //	row=i;
    	col_num = i;
    	   row = sheet.getRow(i);
    }
       
for(int j=0;j<= row.getLastCellNum();j++){
// col_num = j;

XSSFCell cell = row.getCell(col_num+1);

String value = cell.getStringCellValue();
System.out.println("Value of the Excel Cell is - "+ value);
//col_num++;
//row++;
    }
    }
}
}*/