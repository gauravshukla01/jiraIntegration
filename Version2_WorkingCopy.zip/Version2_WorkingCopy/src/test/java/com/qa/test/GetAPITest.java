package com.qa.test;

import java.io.IOException;

import org.apache.http.auth.AuthenticationException;
import org.apache.http.client.ClientProtocolException;
import org.json.JSONException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.client.RestClient;

public class GetAPITest extends TestBase{
	TestBase testbase;
	String serviceurl;
	String apiurl;
	String url;
	RestClient restclient;
	
	
	@BeforeMethod
public void setup() throws ClientProtocolException, IOException, JSONException{
	testbase=new TestBase();
	 serviceurl=prop.getProperty("URL");
	 apiurl=prop.getProperty("serviceURL1");
	// url=serviceurl+apiurl;
	 //url="https://jira-qa.aexp.com/jira/rest/api/2/issue/ECPDTC-106?fields&expand";
	 
	 url="https://jira.aexp.com/jira/rest/zapi/latest/stepResult?executionId=74720";
}
@Test
public void getAPITest() throws ClientProtocolException, IOException, JSONException, AuthenticationException{
	 restclient=new RestClient();
	restclient.get(url);
	}
@Test
public String getid() throws ClientProtocolException, IOException, JSONException, AuthenticationException{
	 restclient=new RestClient();
	String id=restclient.get(url);
	System.out.println("ID from the methosis:"+id);
	return id;
	}
}

