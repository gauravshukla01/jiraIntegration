package com.qa.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.auth.AuthenticationException;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.qa.base.TestBase;
import com.qa.client.RestClient;
import com.qa.data.Execution;
import com.qa.data.Execution_TS;
import com.qa.data.TestCase;
import com.qa.data.TestStep;

@JsonAutoDetect(fieldVisibility = Visibility.ANY)
public class Validation extends TestBase{
	TestBase testbase;
	String endpointurl=prop.getProperty("Host");;
	String apiurl;
	
	RestClient restclient;
	CloseableHttpResponse closablehttpresponse;
	//RestClient restClient;
	GetAPITest getAPITestobj;
	String posturl1;

	public static String url5;
	static String url6; 
	static String issueID = null;
	static String statusValue = null;
	String TestCycleNameExp;
	String projectName=prop.getProperty("ProjectName");
	String TestCycleName=prop.getProperty("TestCycleName");
	String projectID;
	String cycleID;
	String pathname="./TestResults";
	boolean uploadsuccess;
	//String TestCycleNameExp;
	//=prop.getProperty("ProjectId");
	static String status;
	static XSSFSheet ExcelWSheet;
	static XSSFWorkbook ExcelWBook;
	static XSSFCell Cell;
	static FileInputStream fis = null;
	static XSSFRow row;
	String orderId = null;
	//TestCase testCase=new TestCase(TestCase.issuetype,TestCase.project,TestCase.assignee,TestCase.priority,TestCase.summary,TestCase.description,TestCase.customfield_13500,TestCase.customfield_10100);
	//String dis1 
	static String dis1;
	static String desc;
	static String Step ;
	static String Exptval ;
	static String Testdata;
	static String ExternalID;
	public static String Priority;
	public static String Assignee;
	static String testtype;
	static int descIndex = 0; 
	String responsestring = null;
	public static CloseableHttpClient httpClient;
	public static HttpGet httpget;
	public static CloseableHttpResponse closehttpresponse;
	//prop =new Properties();
	//String TestCycleName=prop.getProperty("TestCycleName");
	//String TestCycleName=prop.getProperty("TestCycleName");
	public static String user;//=prop.getProperty("UserName");
	public static String pwd;//=decryptPwd(prop.getProperty("EncryptedPassword"));
	//String endpointurl=prop.getProperty("Host");
	ExecuteExisiting postAPITest2=new ExecuteExisiting();
	int  orderId1;
	//public static String url5;
/*@Test
public void ScenariosUploadAPI() throws Exception{
	getExcelDesc();
	 id=scenariosUpload();
	 
	 System.out.println("Project is"+id);
	 testStepsUpload(id);
	 }
public void testStepsUpload(String projectID) throws Exception{
	System.out.println("Project is in testStepsUpload methos "+id);

	 int test=1;
	int s;
	for(int i=1;i<=ExcelWSheet.getLastRowNum();i++)
	{
		 dis1 = getCellData1(i, descIndex);
		 Step = getCellData1(i, descIndex+1);
		 Exptval = getCellData1(i, descIndex+2);
		 Testdata= getCellData1(i, descIndex+3);
		s=i+1;
		String nextdis1 = null;
		try{
		if((nextdis1 = getCellData1(s, descIndex+1))==null){
			break;
			}
		
		
	else{
		nextdis1 = getCellData1(s, descIndex);
	}
		}catch(NullPointerException e){
		//String nextdis1 = getCellData1(s, intDesclm);
		}
		postrequest();
		
		if(!nextdis1.isEmpty())
		{
			
			System.out.println(":::::::::::::New Test case:::::::::::"+test+++"::::::::::::");
			System.out.println("::We are goint to next test case::::::::::");
			
			System.out.println(":::Discription::"+nextdis1);
			
			//break;
			 id=scenariosUpload();
		}
		
	}
}
public static String getCellData1(int RowNum, int ColNum) throws Exception {
	Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);
	String CellData = Cell.getStringCellValue().toString();
	return CellData;
}
	

public String scenariosUpload() throws Exception{
	
	String responsestring = null;

	 restclient=new RestClient();
	 HashMap<String,String> headermap=new HashMap<String,String>();
	 headermap.put("Content-Type", "application/json");
	
	// ObjectMapper mapper=new ObjectMapper();
	//Execution execution =new Execution(getid(),Integer.parseInt(getProjectID()),Integer.parseInt(status),getTestCycleID());//"3216");//,get);
	// Execution execution =new Execution("1");
	 //HashMap issuetype1= TestCase.getIssuetype(TestCase.issuetype);
	 //System.out.println(issuetype1);
	 ObjectMapper objectMapper = new ObjectMapper();
	    objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
	    objectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
	    //objectMapper.se
	    //objectMapper.sets
	    
	    
	    int test=1;
		int s;
		for(int i=1;i<=ExcelWSheet.getLastRowNum();i++)
		{    
			 Testdata= getCellData1(i, descIndex+3);
	 TestCase.issuetype=testCase.getIssuetype();
	 TestCase.project=testCase.getProject();
	 TestCase.assignee=testCase.getAssignee();	 
	 TestCase.priority=testCase.getPriority();
	//TestCase.summary=testCase.getSummary();
	 TestCase.summary=Testdata;
	// TestCase.description=testCase.getDescription();
	 
	 TestCase.customfield_10100=testCase.getCustomfield_10100();
	 TestCase.priority=testCase.getPriority();
	 
	 TestCase testcase=new TestCase(TestCase.issuetype,TestCase.project,TestCase.assignee,TestCase.priority,TestCase.summary,dis1, TestCase.customfield_13500,"Stringcustomfield_10100");//,null,"summary","Project",null,null,null,"description",null);
	 objectMapper.writeValue(new File("./src/main/java/com/qa/data/testcase.json"), testcase);
	 String executionjsonString12=objectMapper.writeValueAsString(testcase);
	 String strar="{\"fields\":";
	 
	 System.out.println(executionjsonString12);
	 String executionjsonString=strar+executionjsonString12+"}";
	 System.out.println(executionjsonString);
	 closablehttpresponse= restclient.post("https://jira.aexp.com/jira/rest/api/2/issue/", executionjsonString, headermap);
	
	 int StatusCode=closablehttpresponse.getStatusLine().getStatusCode();
	// Assert.assertEquals(StatusCode,200);
	 org.apache.http.Header[] headerarray= closablehttpresponse.getAllHeaders();
		HashMap<String,String> allheaders=new HashMap<String,String>();
		for(org.apache.http.Header header:headerarray){
			allheaders.put(header.getName(),header.getValue());
		}
	//	System.out.println("Headers are ===="+allheaders);

	  responsestring=EntityUtils.toString(closablehttpresponse.getEntity());
	 JSONObject responsejson=new JSONObject(responsestring);
	 
	 System.out.println("RESPONSE fROM th API IS----" +responsejson);
	 try{
			id = (String) responsejson.get("id");
			 System.out.println("id is=------"+id);
			}catch(Exception e){
				id =String.valueOf(responsejson.get("id"));  
				 System.out.println("id is=------"+id);
			}
		}
			 return id;
}
public void getExcelDesc() throws Exception{
	fis = new FileInputStream(("./ExcelSheet/JIRAUpload123.xlsx"));

	ExcelWBook = new XSSFWorkbook(fis);
	ExcelWSheet = ExcelWBook.getSheetAt(0);

	int desrow = 0;
	
	int s=0;
    int chk=0;
    int test=1;
	for (int ir = 0; ir <= ExcelWSheet.getLastRowNum(); ir++) {

		//System.out.println(":::Row::" + ir + "::Max cal::" + ExcelWSheet.getPhysicalNumberOfRows());
		for (int jC = 0; jC <= ExcelWSheet.getPhysicalNumberOfRows(); jC++) {

			dis1 = getCellData1(ir, jC);

			if (dis1.contains("Description")) {
				System.out.println(":::dis is matching discripy::");
				desrow = ir;
				descIndex = jC;
				System.out.println("Matchi9ng::Row::" + desrow + "::Maching column::" +descIndex);
				desc = getCellData1(desrow+1, descIndex);

				System.out.println(":::::::::::::New Test case:::::::::::"+test+++"::::::::::::");
				System.out.println(desrow+":::Discription::"+desc);
			chk=1;
			break;
      			}
			
		}
		if(chk>=1)
		{
			break;
		}
		

	}
	
}
public void postrequest() throws JsonGenerationException, JsonMappingException, IOException, AuthenticationException, JSONException{
	posturl1=endpointurl+"/rest/zapi/latest/teststep/"+id+"";
	restclient=new RestClient();
	 HashMap<String,String> headermap=new HashMap<String,String>();
	 headermap.put("Content-Type", "application/json");
	
	 ObjectMapper mapper=new ObjectMapper();
	//Execution execution =new Execution(getid(),Integer.parseInt(getProjectID()),Integer.parseInt(status),getTestCycleID());//"3216");//,get);
	TestStep ts =new TestStep(Step,Exptval,Testdata);
	 mapper.writeValue(new File("./src/main/java/com/qa/data/teststep.json"), ts);
	 String executionjsonString=mapper.writeValueAsString(ts);
	 System.out.println(executionjsonString);
	 closablehttpresponse= restclient.post(posturl1, executionjsonString, headermap);
	
	 int StatusCode=closablehttpresponse.getStatusLine().getStatusCode();
	// Assert.assertEquals(StatusCode,200);
	 org.apache.http.Header[] headerarray= closablehttpresponse.getAllHeaders();
		HashMap<String,String> allheaders=new HashMap<String,String>();
		for(org.apache.http.Header header:headerarray){
			allheaders.put(header.getName(),header.getValue());
		}
	//	System.out.println("Headers are ===="+allheaders);

	  responsestring=EntityUtils.toString(closablehttpresponse.getEntity());
	 JSONObject responsejson=new JSONObject(responsestring);
	 
	 System.out.println("RESPONSE fROM th API IS----" +responsejson);
}*/
	
	//@Test 
public void get() throws ClientProtocolException,IOException, JSONException, AuthenticationException{
		 user=prop.getProperty("UserName");
		 pwd=decryptPwd(prop.getProperty("EncryptedPassword"));
	 httpClient=HttpClients.createDefault();
	 httpget=new HttpGet("https://jira.aexp.com/jira/rest/zapi/latest/teststep/643880");	

   UsernamePasswordCredentials creds
     = new UsernamePasswordCredentials(user, pwd);
   httpget.addHeader(new BasicScheme().authenticate(creds, httpget, null));
		
	 closehttpresponse=httpClient.execute(httpget);
	int StatusCode=closehttpresponse.getStatusLine().getStatusCode();
	
	System.out.println("Staus Code====="+StatusCode);
	
	String response=EntityUtils.toString(closehttpresponse.getEntity());
	
	 System.out.println("Execution id----"+ response.substring(3,7));
	
	JSONObject responsejson=new JSONObject(response.substring(response.indexOf('{')));
	//responsejson.get
	System.out.println("Response JSON"+response);
	org.apache.http.Header[] headerarray= closehttpresponse.getAllHeaders();
	HashMap<String,String> allheaders=new HashMap<String,String>();
	for(org.apache.http.Header header:headerarray){
		allheaders.put(header.getName(),header.getValue());
	}
	//System.out.println("Headers are ===="+allheaders);
	if(response.charAt(0)=='['){
	JSONArray jsonarray=new JSONArray(response); 
	for(int i=0; i<jsonarray.length(); i++){
       JSONObject obj = jsonarray.getJSONObject(i);

   
       System.out.println("Test Step["+i+"] ID is "+obj.get("orderId"));
      // url5=endpointurl+"/rest/zapi/latest/stepResult/"+obj.get("id")+"";
       //postAPITest2.putAPITSTest();
       orderId1=(Integer) obj.get("orderId");
       System.out.println(orderId1);
   }   
	
	}
	try{
		orderId1 = (Integer) responsejson.get("orderId");
	 System.out.println("id is=------"+orderId);
	}catch(Exception e){
		orderId =String.valueOf(responsejson.get("orderId"));  
		 System.out.println("id is=------"+orderId);
	}
	 //return orderId;
	//closehttpresponse.
}

public static String decryptPwd(String Name)
{
	byte[] decodeBytes = Base64.decodeBase64(Name);
	String decodedString = new String(decodeBytes);
	return decodedString;
}
@Test
public void getfilename(){
	

	 String FileName =null;
	 //File aFile;
File filename = null;
String[] CredentialsInput = null;
//String pathname= "./TestResults/TestScenarios.xls"; 
File[] files=new File(pathname).listFiles();
int filecount=files.length;
if(filecount>0){
//for(int i=0;i<filecount;i++){
	for (File aFile : files) {
		System.out.println(aFile.getName());
		
		File fileUpload = new File(pathname+"/"+aFile.getName());
		System.out.println(fileUpload);

}
}
}
}

