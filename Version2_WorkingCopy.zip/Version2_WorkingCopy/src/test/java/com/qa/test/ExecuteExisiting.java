package com.qa.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.auth.AuthenticationException;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.json.JSONArray;
/*import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;*/
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.qa.base.TestBase;
import com.qa.client.RestClient;
import com.qa.data.ExecuteWithCycle;
import com.qa.data.Execution;
import com.qa.data.ExecutionBasic;
import com.qa.data.Execution_TS;
import com.qa.data.UpdateWorkFlow;

import java.lang.reflect.Type;

public class ExecuteExisiting extends TestBase{
	//Gson gson = new Gson();
	TestBase testbase;
	String endpointurl;
	String apiurl;
	
	RestClient restclient;
	CloseableHttpResponse closablehttpresponse;
	//RestClient restClient;
	GetAPITest getAPITestobj;
	String url1;
	String url2;
	String url3;
	String url4;
	public static String url5;
	static String url6; 
	static String issueID = null;
	static String statusValue = null;
	static String FileUpload = null;
	static String FileName =null;
	static String workflowstatus=null;
	String TestCycleNameExp;
	String projectName=prop.getProperty("ProjectName");
	String TestCycleName=prop.getProperty("TestCycleName");
	String VersionName=prop.getProperty("VersionName");
	String projectID;
	int versionID;
	String cycleID;
	String pathname="./TestResults";
	boolean uploadsuccess;
	
	//String TestCycleNameExp;
	//=prop.getProperty("ProjectId");
	static String status;
	static String wrkflowstatus;
	//String projectID;
	@BeforeSuite
	public void projectinfo() throws AuthenticationException, ClientProtocolException, ParseException, IOException, JSONException{
		endpointurl=prop.getProperty("Host");
		projectID=getProjectID();
		System.out.println("Given project Name is::" +projectName +"and it key is::"+projectID);
		
		System.out.println("Given TestCycleName  is::" +TestCycleName);
		System.out.println("Given VersionName  is::" +VersionName);
		
		if(!(VersionName.equalsIgnoreCase("NA"))){
		versionID=getVersionID();
		System.out.println("Test Cyccle given is::" +VersionName+"and it key is::"+versionID);
		}
		if(!(TestCycleName.equalsIgnoreCase("NA"))){
		cycleID=getTestCycleID();
		System.out.println("Test Cyccle given is::" +TestCycleName+"and it key is::"+cycleID);
		}
	}
@BeforeTest
public void setup() throws Exception{

	 endpointurl=prop.getProperty("Host");
	 
	 FileInputStream fis = new FileInputStream("./ExcelSheet/TestScenarios.xls");
		HSSFWorkbook wb = new HSSFWorkbook(fis);
		HSSFSheet sheet0 = wb.getSheetAt(0);
		int rowNum = sheet0.getLastRowNum();
		System.out.println("row : " + rowNum);
		for (int i = 1; i <= rowNum; i++)
			{
			
			issueID = sheet0.getRow(i).getCell(0).getStringCellValue();
			statusValue = sheet0.getRow(i).getCell(1).getStringCellValue();
			FileUpload = sheet0.getRow(i).getCell(2).getStringCellValue();
			workflowstatus=sheet0.getRow(i).getCell(4).getStringCellValue();
			
			
			
			
			System.out.println(i + ".Issue id :" + issueID);
			System.out.println("statusValue :" + statusValue);
			if(!(statusValue==null)){
				if(statusValue.equalsIgnoreCase("pass")){
					status="1";
				}
				else if(statusValue.equalsIgnoreCase("fail")){
					status="2";
				}
				else if(statusValue.equalsIgnoreCase("WIP")){
					status="3";
				}
				}
			if(FileUpload.equalsIgnoreCase("YES")){
				FileName= sheet0.getRow(i).getCell(3).getStringCellValue();
			uploadsuccess= addAttachmentToIssue(issueID,pathname);
			Assert.assertEquals(uploadsuccess,true);
			}
			if(!(workflowstatus==null)){
				updateWorkflowStatus();
			}
			url1=endpointurl+"/rest/api/2/issue/"+issueID+"?fields&expand";
			url2=endpointurl+"/rest/zapi/latest/execution";
			
			//getid();
			String execid=postAPITest();
			url3=endpointurl+"/rest/zapi/latest/execution/"+execid+"/execute";
			putAPITest();
			
			url4=endpointurl+"/rest/zapi/latest/stepResult?executionId="+execid+"";
			
			String tsid=restclient.get(url4);
			
			
			}
}

//@Test(priority=2)
public String getid() throws ClientProtocolException, IOException, JSONException, AuthenticationException{
	FileInputStream fis = new FileInputStream("./ExcelSheet/TestScenarios.xls");
	HSSFWorkbook wb = new HSSFWorkbook(fis);
	HSSFSheet sheet0 = wb.getSheetAt(0);
	int rowNum = sheet0.getLastRowNum();
	
	//Click on More actions for linking test cases with user story
	
	System.out.println("inside of getid method");
	String id = null;
	for(int i = 0; i <= rowNum;)
	{
	 restclient=new RestClient();
	
	 id=restclient.get(url1);
	
	System.out.println("ID from the methosis:"+id);
	
	break;
	}
	return id;
	}


//@Test(priority=3)

public String postAPITest() throws ClientProtocolException, IOException, JSONException, AuthenticationException{
	FileInputStream fis = new FileInputStream("./ExcelSheet/TestScenarios.xls");
	HSSFWorkbook wb = new HSSFWorkbook(fis);
	HSSFSheet sheet0 = wb.getSheetAt(0);
	int rowNum = sheet0.getLastRowNum();
	
	//Click on More actions for linking test cases with user story
	
	System.out.println("inside of postAPITest method");
	String responsestring = null;
	for(int i = 0; i <= rowNum;)
	{
	 restclient=new RestClient();
	 HashMap<String,String> headermap=new HashMap<String,String>();
	 headermap.put("Content-Type", "application/json");
	
	 ObjectMapper mapper=new ObjectMapper();
	 if(!(TestCycleName==null)&&(VersionName==null)){
	Execution execution =new Execution(getid(),Integer.parseInt(projectID),Integer.parseInt(status),cycleID,versionID);//"3216");//,get);
	// Execution execution =new Execution("1");
	 mapper.writeValue(new File("./src/main/java/com/qa/data/execution.json"), execution);
	 String executionjsonString=mapper.writeValueAsString(execution);
	 System.out.println(executionjsonString);
	 closablehttpresponse= restclient.post(url2, executionjsonString, headermap);
	 }
	 else if(TestCycleName==null){
		 ExecutionBasic executionbs =new ExecutionBasic(getid(),Integer.parseInt(projectID),Integer.parseInt(status));//,cycleID,versionID);//"3216");//,get);
			// Execution execution =new Execution("1");
			 mapper.writeValue(new File("./src/main/java/com/qa/data/execution.json"), executionbs);
			 String executionjsonString=mapper.writeValueAsString(executionbs);
			 System.out.println(executionjsonString);
			 closablehttpresponse= restclient.post(url2, executionjsonString, headermap);
		 
	 }
	 else {
		 ExecuteWithCycle executionbs =new ExecuteWithCycle(getid(),Integer.parseInt(projectID),Integer.parseInt(status),cycleID);//,versionID);//"3216");//,get);
			// Execution execution =new Execution("1");
			 mapper.writeValue(new File("./src/main/java/com/qa/data/execution.json"), executionbs);
			 String executionjsonString=mapper.writeValueAsString(executionbs);
			 System.out.println(executionjsonString);
			 closablehttpresponse= restclient.post(url2, executionjsonString, headermap);
		 
	 }
	 int StatusCode=closablehttpresponse.getStatusLine().getStatusCode();
	 Assert.assertEquals(StatusCode,200);
	 org.apache.http.Header[] headerarray= closablehttpresponse.getAllHeaders();
		HashMap<String,String> allheaders=new HashMap<String,String>();
		for(org.apache.http.Header header:headerarray){
			allheaders.put(header.getName(),header.getValue());
		}
	//	System.out.println("Headers are ===="+allheaders);

	  responsestring=EntityUtils.toString(closablehttpresponse.getEntity());
	 JSONObject responsejson=new JSONObject(responsestring);
	 
	 System.out.println("RESPONSE fROM th API IS----" +responsejson);
	
	 System.out.println("Execution id----"+ responsestring.substring(2,7));

	
	break;
	}
	return responsestring.substring(2,7);
	}
	 

//@Test(priority=4)
public void putAPITest() throws ClientProtocolException, IOException, JSONException, AuthenticationException{
	FileInputStream fis = new FileInputStream("./ExcelSheet/TestScenarios.xls");
	HSSFWorkbook wb = new HSSFWorkbook(fis);
	HSSFSheet sheet0 = wb.getSheetAt(0);
	int rowNum = sheet0.getLastRowNum();
	
	//Click on More actions for linking test cases with user story
	
	System.out.println("inside of putAPITest method");
	for(int i = 0; i <= rowNum;)
	{
	 restclient=new RestClient();
	 HashMap<String,String> headermap=new HashMap<String,String>();
	 headermap.put("Content-Type", "application/json");
	
	 ObjectMapper mapper=new ObjectMapper();
	 Execution_TS execution =new Execution_TS(status);
	// Execution execution =new Execution("1");
	 mapper.writeValue(new File("./src/main/java/com/qa/data/execution_ts.json"), execution);
	 String executionjsonString=mapper.writeValueAsString(execution);
	 System.out.println(executionjsonString);
	 closablehttpresponse= restclient.put(url3, executionjsonString, headermap);
	 
	// closablehttpresponse= restclient.put(url4, executionjsonString, headermap);
	
	 int StatusCode=closablehttpresponse.getStatusLine().getStatusCode();
	// Assert.assertEquals(StatusCode,200);
	 /*org.apache.http.Header[] headerarray= closablehttpresponse.getAllHeaders();
		HashMap<String,String> allheaders=new HashMap<String,String>();
		for(org.apache.http.Header header:headerarray){
			allheaders.put(header.getName(),header.getValue());
		}*/
		//System.out.println("Headers are ===="+allheaders);
	 //json string
	// String responsestring=EntityUtils.toString(closablehttpresponse.getEntity(),"UTF-8");
	 String responsestring=EntityUtils.toString(closablehttpresponse.getEntity());
	 JSONObject responsejson=new JSONObject(responsestring);
	 
	 System.out.println("RESPONSE fROM th API IS----" +responsejson);
	
	
	 break;
	}
}
public String getTSid() throws ClientProtocolException, IOException, JSONException, AuthenticationException{
	FileInputStream fis = new FileInputStream("./ExcelSheet/TestScenarios.xls");
	HSSFWorkbook wb = new HSSFWorkbook(fis);
	HSSFSheet sheet0 = wb.getSheetAt(0);
	int rowNum = sheet0.getLastRowNum();
	
	//Click on More actions for linking test cases with user story
	
	System.out.println("inside of getid method");
	String id = null;
	for(int i = 0; i <= rowNum;)
	{
	 restclient=new RestClient();
	
	 id=restclient.get(url4);
	
	System.out.println("ID from the methosis:"+id);
	
	break;
	}
	return id;
	}
public void putAPITSTest() throws ClientProtocolException, IOException, JSONException, AuthenticationException{
	FileInputStream fis = new FileInputStream("./ExcelSheet/TestScenarios.xls");
	HSSFWorkbook wb = new HSSFWorkbook(fis);
	HSSFSheet sheet0 = wb.getSheetAt(0);
	int rowNum = sheet0.getLastRowNum();
	
	//Click on More actions for linking test cases with user story
	
	System.out.println("inside of putAPITest method");
	for(int i = 0; i <= rowNum;)
	{
	 restclient=new RestClient();
	 HashMap<String,String> headermap=new HashMap<String,String>();
	 headermap.put("Content-Type", "application/json");
	
	 ObjectMapper mapper=new ObjectMapper();
	 Execution_TS execution =new Execution_TS(status);
	// Execution execution =new Execution("1");
	 mapper.writeValue(new File("./src/main/java/com/qa/data/execution_ts.json"), execution);
	 String executionjsonString=mapper.writeValueAsString(execution);
	 System.out.println(executionjsonString);
	// url5=url5;
	 closablehttpresponse= restclient.put(RestClient.url5, executionjsonString, headermap);
	 
	// closablehttpresponse= restclient.put(url4, executionjsonString, headermap);
	
	 int StatusCode=closablehttpresponse.getStatusLine().getStatusCode();
	// Assert.assertEquals(StatusCode,200);
	 org.apache.http.Header[] headerarray= closablehttpresponse.getAllHeaders();
		HashMap<String,String> allheaders=new HashMap<String,String>();
		for(org.apache.http.Header header:headerarray){
			allheaders.put(header.getName(),header.getValue());
		}
		//System.out.println("Headers are ===="+allheaders);
	 //json string
	// String responsestring=EntityUtils.toString(closablehttpresponse.getEntity(),"UTF-8");
	 String responsestring=EntityUtils.toString(closablehttpresponse.getEntity());
	 JSONObject responsejson=new JSONObject(responsestring);
	 
	 System.out.println("RESPONSE fROM th API IS----" +responsejson);
	 break;
	}
}
public String getProjectID() throws ClientProtocolException, IOException, JSONException, AuthenticationException, ParseException{
	 CloseableHttpClient httpClient1;
	HttpGet httpget1;
	CloseableHttpResponse closehttpresponse1;
	String Projectdetailscall=endpointurl+"/rest/api/2/project";
	 restclient=new RestClient();
	 httpClient1=HttpClients.createDefault();
	httpget1=new HttpGet(Projectdetailscall);	

    UsernamePasswordCredentials creds
      = new UsernamePasswordCredentials(RestClient.user, RestClient.pwd);
    httpget1.addHeader(new BasicScheme().authenticate(creds, httpget1, null));
		
    closehttpresponse1=httpClient1.execute(httpget1);
	int StatusCode=closehttpresponse1.getStatusLine().getStatusCode();
	Assert.assertEquals(StatusCode, 200);
	//System.out.println("Staus Code====="+StatusCode);
	
	String response=EntityUtils.toString(closehttpresponse1.getEntity());
	// projectID=restclient.get(Projectdetailscall);
	if(response.charAt(0)=='['){
		JSONArray jsonarray=new JSONArray(response); 
		for(int i=0; i<jsonarray.length(); i++){
	        JSONObject obj = jsonarray.getJSONObject(i);
	        
	       // System.out.println("+++++"+obj.getString("key"));
	        //System.out.println("project["+i+"] is "+obj.get("key"));
	        
	        
	        
	        if(projectName.equalsIgnoreCase((String) obj.get("key"))){
	        	projectID=(String) obj.get("id");
	        	break;
	        }
	        //url5=endpointurl+"/rest/zapi/latest/stepResult/"+obj.get("id")+"";
	        //postAPITest2.putAPITSTest();
		
	    }   
		}
return projectID;
	
}
public int getVersionID() throws ClientProtocolException, IOException, JSONException, AuthenticationException, ParseException{
	 CloseableHttpClient httpClient1;
	HttpGet httpget1;
	CloseableHttpResponse closehttpresponse1;
	String Versiondetailscall=endpointurl+"/rest/api/2/project/"+projectID+"/versions";
	 restclient=new RestClient();
	 httpClient1=HttpClients.createDefault();
	httpget1=new HttpGet(Versiondetailscall);	

   UsernamePasswordCredentials creds
     = new UsernamePasswordCredentials(RestClient.user, RestClient.pwd);
   httpget1.addHeader(new BasicScheme().authenticate(creds, httpget1, null));
		
   closehttpresponse1=httpClient1.execute(httpget1);
	int StatusCode=closehttpresponse1.getStatusLine().getStatusCode();
	
	//System.out.println("Staus Code====="+StatusCode);
	
	String response=EntityUtils.toString(closehttpresponse1.getEntity());
	// projectID=restclient.get(Projectdetailscall);
	if(response.charAt(0)=='['){
		
		JSONArray jsonarray=new JSONArray(response); 
		
		for(int i=0; i<jsonarray.length(); i++){
	        JSONObject obj = jsonarray.getJSONObject(i);
	        
	        //System.out.println("+++++"+obj.getString("key"));
	        //System.out.println("project["+i+"] is "+obj.get("name"));
	       // System.out.println(obj.get("name").toString());
	        String tocompare=obj.get("name").toString().trim();
	        
	        if(VersionName.trim().equalsIgnoreCase(tocompare)){
	        	versionID=Integer.parseInt((String) obj.get("id"));
	        	break;
	        }
	        //url5=endpointurl+"/rest/zapi/latest/stepResult/"+obj.get("id")+"";
	        //postAPITest2.putAPITSTest();
		
	    }   
		}
return versionID;
	
}

public final String getTestCycleID() throws ClientProtocolException, IOException, JSONException, AuthenticationException, ParseException{
	String Cycledetailscall;
	if(!(VersionName.equalsIgnoreCase("NA"))){
	 Cycledetailscall=endpointurl+"/rest/zapi/latest/cycle?projectId="+projectID+"&versionId="+versionID+"";
}
else{
	 Cycledetailscall=endpointurl+"/rest/zapi/latest/cycle?projectId="+projectID+"";
}
	 restclient=new RestClient();
		CloseableHttpClient httpClient=HttpClients.createDefault();

		HttpGet httpget=new HttpGet(Cycledetailscall);
		
	    UsernamePasswordCredentials creds
	      = new UsernamePasswordCredentials(RestClient.user, RestClient.pwd);
	    httpget.addHeader(new BasicScheme().authenticate(creds, httpget, null));	
		
		CloseableHttpResponse closehttpresponse=httpClient.execute(httpget);
		
		int StatusCode=closehttpresponse.getStatusLine().getStatusCode();
		
		//System.out.println("Staus Code====="+StatusCode);
		
		String response=EntityUtils.toString(closehttpresponse.getEntity());
		
		 //System.out.println("Execution id----"+ response.substring(3,7));
		
		JSONObject responsejson=new JSONObject(response.substring(response.indexOf('{')));
		//JSONObject responsejson=new JSONObject(response);//.substring(response.indexOf('{')));
		//responsejson.get
		//System.out.println("Response JSON"+response);
		org.apache.http.Header[] headerarray= closehttpresponse.getAllHeaders();
		/*HashMap<String,String> allheaders=new HashMap<String,String>();
		for(org.apache.http.Header header:headerarray){
			allheaders.put(header.getName(),header.getValue());
		}*/
	 //cycleID=restclient.get(Cycledetailscall);
		//JSONObject categoryObject = responsejson.getNames();
		JSONArray jsonarray;
		if(Cycledetailscall.contains("cycle")){
			if(response.contains("[")){
				//System.out.println("respoense for cycle" +response);
				if(!(VersionName.equalsIgnoreCase("NA"))){
				 jsonarray=new JSONArray("["+responsejson+"]");
				}
				else{
				 jsonarray=new JSONArray(response.substring(6)); 
				}
				for(int i=0; i<jsonarray.length(); i++){
			        JSONObject obj = jsonarray.getJSONObject(i);
			      
			        
			    
			      //  System.out.println("Test Step["+i+"] ID is "+obj);		       
			       //System.out.println(obj.names().get(i));
			       for(int j=0;j<obj.names().length();j++){
			       url6=endpointurl+"/rest/zapi/latest/cycle/"+obj.names().get(j)+"";
			        	//cycleId=(String) obj.names().get(i);
			       if(!(url6.contains("recordsCount"))){
			        	String projcomp=getTestCycleInfo(url6);
			        	if(!(projcomp==null)){
			        	//calling the service to fetch the cycle details
			        	if(projcomp.trim().contains(TestCycleName.trim())){
			        		cycleID=(String) obj.names().get(j);
			        		// break;
			        		break;
			        	}
			       }
			       }
			       }
			        	}   
		}
			
		}
		return cycleID;

	}
public String getTestCycleInfo(String url) throws ClientProtocolException, IOException, JSONException, AuthenticationException, ParseException{
	
	CloseableHttpClient httpClient1=HttpClients.createDefault();
	HttpGet httpget1=new HttpGet(url);	
    UsernamePasswordCredentials creds
      = new UsernamePasswordCredentials(RestClient.user, RestClient.pwd);
    httpget1.addHeader(new BasicScheme().authenticate(creds, httpget1, null));
	
	CloseableHttpResponse closehttpresponse=httpClient1.execute(httpget1);
	
	int StatusCode=closehttpresponse.getStatusLine().getStatusCode();	
	System.out.println("Staus Code====="+StatusCode);	
	String response12=EntityUtils.toString(closehttpresponse.getEntity());
	if(!(response12.contains("Cycle doesnt exist"))){
	if(!(url.contains("recordsCount"))){
	JSONObject responsejson1=new JSONObject(response12.substring(response12.indexOf('{')));
	try{
		TestCycleNameExp = (String) responsejson1.get("name");
		System.out.println("Test Cycle name is=------"+TestCycleNameExp);
		}catch(Exception e){
			TestCycleNameExp =String.valueOf(responsejson1.get("name"));  
			System.out.println(TestCycleNameExp);
		}
	}	
	}
	return TestCycleNameExp;
	}
public boolean addAttachmentToIssue(String issueKey, String fullfilename) throws IOException, AuthenticationException{
	boolean uplaodstatus = false;
	System.out.println("v are in Fileattachement method");
	String filename = null;
	String[] CredentialsInput = null;
	//String pathname= "./TestResults/TestScenarios.xls"; 
	File[] files=new File(pathname).listFiles();
	int filecount=files.length;
	if(filecount>0){
	//for(int i=0;i<filecount;i++){
		if(FileName.contains("|")){
			CredentialsInput = FileName.split("\\|");
			for(int j=0;j<CredentialsInput.length;j++){
			 filename = CredentialsInput[j];
			File fileUpload = new File(pathname+"/"+filename);
			HttpClient httpClient = HttpClientBuilder.create().build();
			//baseURL+"issue/"+issueKey+"/attachments
			HttpPost postRequest = new HttpPost("https://jira.aexp.com/jira/rest/api/2/issue/"+issueID+"/attachments");
			CloseableHttpClient httpClient12=HttpClients.createDefault();

			//HttpGet httpget=new HttpGet("https://jira.aexp.com/jira/rest/api/2/issue/"+issueID+"/attachments");
			 UsernamePasswordCredentials creds
		     = new UsernamePasswordCredentials(RestClient.user, RestClient.pwd);
			 postRequest.addHeader(new BasicScheme().authenticate(creds, postRequest, null));	
		   
			postRequest.setHeader("X-Atlassian-Token","nocheck");
			MultipartEntityBuilder entity=MultipartEntityBuilder.create();

			FileBody fileBody = new FileBody(fileUpload, "application/octet-stream");
			entity.addPart("file", new FileBody(fileUpload));
			postRequest.setEntity( entity.build());
			HttpResponse response = httpClient.execute(postRequest);
			System.out.println(response);
			 String responsestring = EntityUtils.toString(response.getEntity());
			 
			if(response.getStatusLine().getStatusCode()==Integer.parseInt("200")){
				uplaodstatus= true;
			}
			else{
				uplaodstatus= false;
			}
			}
		}
		
		else{
			 filename=FileName;
		
	File fileUpload = new File(pathname+"/"+filename);
	HttpClient httpClient = HttpClientBuilder.create().build();
	//baseURL+"issue/"+issueKey+"/attachments
	HttpPost postRequest = new HttpPost("https://jira.aexp.com/jira/rest/api/2/issue/"+issueID+"/attachments");
	CloseableHttpClient httpClient12=HttpClients.createDefault();

	//HttpGet httpget=new HttpGet("https://jira.aexp.com/jira/rest/api/2/issue/"+issueID+"/attachments");
	 UsernamePasswordCredentials creds
     = new UsernamePasswordCredentials(RestClient.user, RestClient.pwd);
	 postRequest.addHeader(new BasicScheme().authenticate(creds, postRequest, null));	
   
	postRequest.setHeader("X-Atlassian-Token","nocheck");
	MultipartEntityBuilder entity=MultipartEntityBuilder.create();

	FileBody fileBody = new FileBody(fileUpload, "application/octet-stream");
	entity.addPart("file", new FileBody(fileUpload));
	postRequest.setEntity( entity.build());
	HttpResponse response = httpClient.execute(postRequest);
	System.out.println(response);
	 String responsestring = EntityUtils.toString(response.getEntity());
	if(response.getStatusLine().getStatusCode()==Integer.parseInt("200")){
		uplaodstatus= true;
	}
	else{
		uplaodstatus= false;
	}
	}
	//}	
	}
	else{
		System.out.println("Please place the Testresults files in the TestFolder");
		uplaodstatus=false;
	}
	return uplaodstatus;
	}
public void updateWorkflowStatus() throws ClientProtocolException, IOException, JSONException, AuthenticationException, ParseException{
	
	String url=endpointurl+"/rest/api/2/issue/"+projectID+"/transitions";
	restclient=new RestClient();
	 HashMap<String,String> headermap=new HashMap<String,String>();
	 headermap.put("Content-Type", "application/json");
	
	 ObjectMapper mapper=new ObjectMapper();
	 if(workflowstatus.equalsIgnoreCase("close")){
		 wrkflowstatus="141";
		 UpdateWorkFlow workflow =new UpdateWorkFlow(wrkflowstatus);//,get);
	// Execution execution =new Execution("1");
	 mapper.writeValue(new File("./src/main/java/com/qa/data/workflow.json"), workflow);
	 String executionjsonString12=mapper.writeValueAsString(workflow);
	 String strar="{\"transition\":";
	 String executionjsonString=strar+executionjsonString12+"}";
	 System.out.println(executionjsonString);
	 closablehttpresponse= restclient.post(url, executionjsonString, headermap);
	 }
	
	
}
}

