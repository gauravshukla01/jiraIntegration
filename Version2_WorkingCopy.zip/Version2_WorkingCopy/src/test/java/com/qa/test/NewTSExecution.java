package com.qa.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.auth.AuthenticationException;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
/*import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;*/
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.qa.base.TestBase;
import com.qa.client.RestClient;
import com.qa.data.Execution;
import com.qa.data.Execution_TS;
import com.qa.data.TestCase;
import com.qa.data.TestCaseWithOutSprint;
import com.qa.data.TestStep;
@JsonAutoDetect(fieldVisibility = Visibility.ANY)
public class NewTSExecution extends TestBase{
	//TestBase testbase;
	String endpointurl;//
	//String apiurl;
	
	RestClient restclient;
	CloseableHttpResponse closablehttpresponse;
	//RestClient restClient;
	//GetAPITest getAPITestobj;
	String posturl1;

	//public static String url5;
	//static String url6; 
	static String issueID = null;
	static String statusValue = null;
	String TestCycleNameExp;
	public static String projectName=null;//=prop.getProperty("ProjectName");
	String TestCycleName=prop.getProperty("TestCycleName");
	static XSSFSheet ExcelWSheet;
	static XSSFWorkbook ExcelWBook;
	static XSSFCell Cell;
	static FileInputStream fis = null;
	static XSSFRow row;
	String id = null;
	TestCase testCase=new TestCase(TestCase.issuetype,TestCase.project,TestCase.assignee,TestCase.priority,TestCase.summary,TestCase.description,TestCase.customfield_13500,TestCase.customfield_10100,TestCase.label,TestCase.customfield_10004);
	//String dis1 
	public static String dis1;
	static String desc;
	static String Step ;
	static String Exptval ;
	static String Testdata;
	static String ExternalID;
	public static String Priority;
	public static String Assignee;
	public static String customfield_10100_AC;
	public static String labels;
	public static String sprint;
	public static String customfield_13500_IT;
	public static String customfield_13500_TT;
	public static int customfield_10004_sprint;
	public static String summary;
	static String testtype;
	static int descIndex = 0; 
	String responsestring = null;
	File file=new File("./output.txt");
	FileOutputStream fos;//=new FileOutputStream(file);
	PrintStream ps;//=new PrintStream(fos);
	 PrintStream console;// = System.out;
	 String pathname="./JIRA_TestCaseUploadTemplate";
	 int rapidviewID;
	 public static int sprintID;
	 public static String sprintName;
	@BeforeSuite
	public void connectsheet() throws Exception{
		getExcelDesc();
		if(!(prop.getProperty("SprintName").equalsIgnoreCase("NA"))){
		sprintID=getSprintId();
		}
		
	}
@Test
public void ScenariosUploadAPI() throws Exception{
	 file=new File("./output.txt");
	 fos=new FileOutputStream(file);
	 ps=new PrintStream(fos);
	 PrintStream console = System.out;
	 System.setOut(ps);
	
	
	
	 id=scenariosUpload();
	 
	// System.out.println("Project is"+id);
	 //testStepsUpload(id);
	 }

public static String getCellData1(int RowNum, int ColNum) throws Exception {
	Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);
	String CellData;
	try{
		CellData = Cell.getStringCellValue().toString();
	}catch(Exception e){
		CellData="";
	}
	return CellData;
}
	

public String scenariosUpload() throws Exception{
	 System.setOut(ps);
	String responsestring = null;

	 restclient=new RestClient();
	 HashMap<String,String> headermap=new HashMap<String,String>();
	 headermap.put("Content-Type", "application/json");
	
	// ObjectMapper mapper=new ObjectMapper();
	//Execution execution =new Execution(getid(),Integer.parseInt(getProjectID()),Integer.parseInt(status),getTestCycleID());//"3216");//,get);
	// Execution execution =new Execution("1");
	 //HashMap issuetype1= TestCase.getIssuetype(TestCase.issuetype);
	 //System.out.println(issuetype1);
	 ObjectMapper objectMapper = new ObjectMapper();
	    objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
	    objectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
	    //objectMapper.se
	    //objectMapper.sets
	    
	    for(int i=1;i<=ExcelWSheet.getLastRowNum();i++)
		{
	    	summary=getCellData1(i, (descIndex-1));
	    	dis1 = getCellData1(i, descIndex);
		   // String dis1 = ReadExcelFile.getCellData(i, descIndex);
		    
	    	projectName=prop.getProperty("ProjectName");
	    	endpointurl=prop.getProperty("Host");
	 TestCase.project=testCase.getProject();
		 
	 //TestCase.priority=testCase.getPriority();
	TestCase.summary=testCase.getSummary();
	 TestCase.description=testCase.getDescription();
	// TestCase.customfield_10100=testCase.getCustomfield_10100();
	 //TestCase.priority=testCase.getPriority();
	 int rowCount = ExcelWSheet.getRow(i).getLastCellNum();
	 if(!dis1.isEmpty()){
		 
		 
		 
		 for(int k=i;k<rowCount;k++){
			 
			 String columnname=ExcelWSheet.getRow(i-1).getCell(k).getStringCellValue();
			 
		 
		if(columnname.equalsIgnoreCase("Priority")){
				Priority=getCellData1(i, k);
		 TestCase.priority=testCase.getPriority();
		}
		if(columnname.equalsIgnoreCase("Assignee")){
		 Assignee=getCellData1(i, k);
		 TestCase.assignee=testCase.getAssignee();
		}
		if(columnname.equalsIgnoreCase("Acceptance Criteria")){
		 customfield_10100_AC= getCellData1(i, k);
		 TestCase.customfield_10100=testCase.getCustomfield_10100();
		}
		if(columnname.equalsIgnoreCase("Labels")){
		 labels= getCellData1(i, k);
		 TestCase.label=testCase.getLabels();
		}
		if(columnname.equalsIgnoreCase("IssueType")){
		 customfield_13500_IT=getCellData1(i, k);
		 TestCase.issuetype=testCase.getIssuetype();
		}
		if(columnname.equalsIgnoreCase("TestType")){
		 customfield_13500_TT=getCellData1(i, k);
		 TestCase.customfield_13500=testCase.getCustomfield_13500();
		}
		
		if(columnname.equalsIgnoreCase("Sprint")&&(!(prop.getProperty("SprintName").equalsIgnoreCase("NA")))){
			//columnname="customfield_10004";
			customfield_10004_sprint=sprintID;
			 TestCase.customfield_10004=testCase.getcustomfield_10004();
			}
		 }
		// projectName
		 
		// Labels 
		 
		// TestType
		 
		 
		if(!(prop.getProperty("SprintName").equalsIgnoreCase("NA"))) {
	 TestCase testcase=new TestCase(TestCase.issuetype,TestCase.project,TestCase.assignee,TestCase.priority,summary,dis1, TestCase.customfield_13500,customfield_10100_AC,TestCase.label,TestCase.customfield_10004);//,null,"summary","Project",null,null,null,"description",null);
	 objectMapper.writeValue(new File("./src/main/java/com/qa/data/testcase.json"), testcase);
	 
	 String executionjsonString12=objectMapper.writeValueAsString(testcase);
	 
	 String strar="{\"fields\":";
	 
	
	 System.out.println(executionjsonString12);
	 String executionjsonString=strar+executionjsonString12+"}";
	 System.out.println(executionjsonString);
	 closablehttpresponse= restclient.post(endpointurl+"/rest/api/2/issue/", executionjsonString, headermap);
		}
		else{
			TestCaseWithOutSprint testcasesprint=new TestCaseWithOutSprint(TestCaseWithOutSprint.issuetype,TestCaseWithOutSprint.project,TestCaseWithOutSprint.assignee,TestCaseWithOutSprint.priority,summary,dis1, TestCaseWithOutSprint.customfield_13500,customfield_10100_AC,TestCaseWithOutSprint.label);//,null,"summary","Project",null,null,null,"description",null);
			 objectMapper.writeValue(new File("./src/main/java/com/qa/data/testcasewithoutsprint.json"), testcasesprint);
			 
			 String executionjsonString12=objectMapper.writeValueAsString(testcasesprint);
			 
			 String strar="{\"fields\":";
			 
			
			 System.out.println(executionjsonString12);
			 String executionjsonString=strar+executionjsonString12+"}";
			 System.out.println(executionjsonString);
			 closablehttpresponse= restclient.post(endpointurl+"/rest/api/2/issue/", executionjsonString, headermap);
		}
	 int StatusCode=closablehttpresponse.getStatusLine().getStatusCode();
	// Assert.assertEquals(StatusCode,200);
	/* org.apache.http.Header[] headerarray= closablehttpresponse.getAllHeaders();
		HashMap<String,String> allheaders=new HashMap<String,String>();
		for(org.apache.http.Header header:headerarray){
			allheaders.put(header.getName(),header.getValue());
		}*/
	//	System.out.println("Headers are ===="+allheaders);

	  responsestring=EntityUtils.toString(closablehttpresponse.getEntity());
	 JSONObject responsejson=new JSONObject(responsestring);
	 System.setOut(console);
	 Assert.assertEquals(StatusCode,201);
	 
	 System.setOut(ps);
	 System.out.println("RESPONSE fROM th API IS----" +responsejson);
	 try{
			id = (String) responsejson.get("id");
			 System.out.println("id is=------"+id);
			 System.out.println("Project is in testStepsUpload method "+id);

			 int test=1;
			int s;
			for(int k=i;k<=ExcelWSheet.getLastRowNum();k++)
			{
				 dis1 = getCellData1(k, descIndex);
				 Step = getCellData1(k, descIndex+1);
				 Exptval = getCellData1(k, descIndex+2);
				 Testdata= getCellData1(k, descIndex+3);
				s=k+1;
				String nextdis1 = null;
				try{
				if((nextdis1 = getCellData1(s, descIndex+1))==null){
					break;
					}
				
				
			else{
				nextdis1 = getCellData1(s, descIndex);
			}
				}catch(NullPointerException e){
				//String nextdis1 = getCellData1(s, intDesclm);
				}
				postrequest();
				if(!(nextdis1.isEmpty())){
					break;
				}
				//break;
				 nextdis1 = getCellData1(s, descIndex);
			}
			 
			 
			}catch(Exception e){
				id =String.valueOf(responsejson.get("id"));  
				 System.out.println("id is=------"+id);
			}
	 }
		}
			 return id;
}
public void getExcelDesc() throws Exception{
	

	File fileUpload = null;
File[] files=new File(pathname).listFiles();
int filecount=files.length;
if(filecount>0){
//for(int i=0;i<filecount;i++){
	for (File aFile : files) {
		System.out.println(aFile.getName());
		
		 fileUpload = new File(pathname+"/"+aFile.getName());
		System.out.println(fileUpload);
		//fileUpload=fileUpload;
	}
}
	fis = new FileInputStream(fileUpload);

	ExcelWBook = new XSSFWorkbook(fis);
	ExcelWSheet = ExcelWBook.getSheetAt(0);

	int desrow = 0;
	
	int s=0;
    int chk=0;
    int test=1;
	for (int ir = 0; ir <= ExcelWSheet.getLastRowNum(); ir++) {

		//System.out.println(":::Row::" + ir + "::Max cal::" + ExcelWSheet.getPhysicalNumberOfRows());
		for (int jC = 0; jC <= ExcelWSheet.getPhysicalNumberOfRows(); jC++) {

			dis1 = getCellData1(ir, jC);

			if (dis1.contains("Description")) {
				//System.out.println(":::dis is matching discripy::");
				desrow = ir;
				descIndex = jC;
				System.out.println("Matching::Row::" + desrow + "::Maching column::" +descIndex);
				desc = getCellData1(desrow+1, descIndex);

				System.out.println(":::::::::::::New Test case:::::::::::"+test+++"::::::::::::");
				System.out.println(desrow+":::Discription::"+desc);
			chk=1;
			break;
      			}
			
		}
		if(chk>=1)
		{
			break;
		}
		

	}
	
}
public void postrequest() throws JsonGenerationException, JsonMappingException, IOException, AuthenticationException, JSONException{
	posturl1=endpointurl+"/rest/zapi/latest/teststep/"+id+"";
	restclient=new RestClient();
	 HashMap<String,String> headermap=new HashMap<String,String>();
	 headermap.put("Content-Type", "application/json");
	
	 ObjectMapper mapper=new ObjectMapper();
	//Execution execution =new Execution(getid(),Integer.parseInt(getProjectID()),Integer.parseInt(status),getTestCycleID());//"3216");//,get);
	TestStep ts =new TestStep(Step,Exptval,Testdata);
	 mapper.writeValue(new File("./src/main/java/com/qa/data/teststep.json"), ts);
	 String executionjsonString=mapper.writeValueAsString(ts);
	 System.out.println(executionjsonString);
	 closablehttpresponse= restclient.post(posturl1, executionjsonString, headermap);
	
	 int StatusCode=closablehttpresponse.getStatusLine().getStatusCode();
	// Assert.assertEquals(StatusCode,200);
	 /*org.apache.http.Header[] headerarray= closablehttpresponse.getAllHeaders();
		HashMap<String,String> allheaders=new HashMap<String,String>();
		for(org.apache.http.Header header:headerarray){
			allheaders.put(header.getName(),header.getValue());
		}*/
	//	System.out.println("Headers are ===="+allheaders);

	  responsestring=EntityUtils.toString(closablehttpresponse.getEntity());
	 JSONObject responsejson=new JSONObject(responsestring);
	 
	 System.out.println("RESPONSE fROM th API IS----" +responsejson);
}
//@Test
public int getSprintId() throws ClientProtocolException, IOException, JSONException, AuthenticationException, ParseException{
	endpointurl=prop.getProperty("Host");
	sprintName= prop.getProperty("SprintName");
	CloseableHttpClient httpClient1;
	HttpGet httpget1;
	CloseableHttpResponse closehttpresponse1;
	String Projectdetailscall=endpointurl+"/rest/greenhopper/1.0/rapidview";
	 restclient=new RestClient();
	 httpClient1=HttpClients.createDefault();
	httpget1=new HttpGet(Projectdetailscall);	

   UsernamePasswordCredentials creds
     = new UsernamePasswordCredentials(RestClient.user, RestClient.pwd);
   httpget1.addHeader(new BasicScheme().authenticate(creds, httpget1, null));
		
   closehttpresponse1=httpClient1.execute(httpget1);
	int StatusCode=closehttpresponse1.getStatusLine().getStatusCode();
	Assert.assertEquals(StatusCode, 200);
	//System.out.println("Staus Code====="+StatusCode);
	
	String response=EntityUtils.toString(closehttpresponse1.getEntity());
	// projectID=restclient.get(Projectdetailscall);
/*	if(response.contains("[")){
		JSONArray jsonarray=new JSONArray("["+response+"]"); 
		for(int i=0; i<jsonarray.length(); i++){
	        JSONObject obj = jsonarray.getJSONObject(i);
	        
	       // System.out.println("+++++"+obj.getString("key"));
	        //System.out.println("project["+i+"] is "+obj.get("key"));
	        
	        
	        
	        if(sprintName.equalsIgnoreCase((String) obj.get("name"))){
	        	sprintID=(int) obj.get("id");
	        	break;
	        }
	        //url5=endpointurl+"/rest/zapi/latest/stepResult/"+obj.get("id")+"";
	        //postAPITest2.putAPITSTest();
		
	    }   
			
		}*/
	JSONObject newJson=new JSONObject(response);
	JSONArray array = (JSONArray) newJson.get("views");
	for(int i=0; i<array.length(); i++){
        JSONObject obj = array.getJSONObject(i);
       // System.out.println(obj.get("name"));
        if(sprintName.equalsIgnoreCase((String) obj.get("name"))){
        	rapidviewID=(int) obj.get("id");
        	System.out.println("RapidView id is:::"+rapidviewID);
        	break;
        }
	}
	//newJson.getJSONObject("views");
	String Projectdetailscall1=endpointurl+"/rest/agile/1.0/board/"+rapidviewID+"/sprint?state=active";
	httpget1=new HttpGet(Projectdetailscall1);	
	 closehttpresponse1=httpClient1.execute(httpget1);
		int StatusCode1=closehttpresponse1.getStatusLine().getStatusCode();
		Assert.assertEquals(StatusCode, 200);
		//System.out.println("Staus Code====="+StatusCode);
		
		String response12=EntityUtils.toString(closehttpresponse1.getEntity());
		JSONObject newJson12=new JSONObject(response12);
		JSONArray array1 = (JSONArray) newJson12.get("values");
		for(int i=0; i<array1.length(); i++){
	        JSONObject obj = array1.getJSONObject(i);
	       // System.out.println(obj.get("name"));

	        	sprintID=(int) obj.get("id");
	        	System.out.println("Active Sprint ID is::" +sprintID);
	        	break;
	        }
		
return sprintID;
	
}
} 




