package com.qa.test;

public class MyObject {

}
